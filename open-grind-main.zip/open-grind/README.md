# Open Grind

[![Matrix space](https://img.shields.io/matrix/opengrind:opengrind.org?server_fqdn=matrix.opengrind.org&fetchMode=summary&label=matrix%20space)](https://matrix.to/#/#opengrind:opengrind.org) [![chat](https://img.shields.io/matrix/general:opengrind.org?server_fqdn=matrix.opengrind.org&fetchMode=summary&label=chat)](https://matrix.to/#/#general:opengrind.org) [![Announcements](https://img.shields.io/matrix/announcements:opengrind.org?server_fqdn=matrix.opengrind.org&fetchMode=summary&label=announcements)](https://matrix.to/#/#announcements:opengrind.org)

**Unofficial Grindr client. Cross-platform, free, libre, ad-free, tracker-free, privacy-centered and community-driven.**

![Screenshots](./contrib/app-screenshots-1x6.avif)

## Download

- **[Download Open Grind](https://opengrind.org/download)** from the official website
- **[Source releases page](https://git.opengrind.org/open-grind/open-grind/releases)** at git.opengrind.org/open-grind/open-grind
- **[Google Play](https://play.google.com/store/apps/details?id=org.opengrind)** for Android

Never install Open Grind from sources not listed above.

## Security

All releases are signed. Learn more in [KEYS.md](./KEYS.md).

Open Grind supports reproducible builds. Learn more in [REPRODUCIBILITY.md](./REPRODUCIBILITY.md).

## Development

Interested in contributing to the project? Head to [CONTRIBUTING.md](./CONTRIBUTING.md) to get started. All contributions must be aligned with [CODE_OF_CONDUCT.md](./CODE_OF_CONDUCT.md).

To build Open Grind yourself, follow [BUILDING.md](./BUILDING.md).

## Problems, bugs, feature requests?

Check out [issues](https://git.opengrind.org/open-grind/open-grind/issues) and the Matrix chatroom [#opengrind:opengrind.org](https://matrix.to/#/#opengrind:opengrind.org).

## License

Code: [MIT](./LICENSE)

Logo, icons and other artwork: [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) (public domain), see [ARTWORK.md](./ARTWORK.md)

## Donate

See [FUNDING.md](./FUNDING.md)
