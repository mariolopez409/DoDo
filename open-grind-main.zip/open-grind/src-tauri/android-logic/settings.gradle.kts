rootProject.name = "android-logic"
