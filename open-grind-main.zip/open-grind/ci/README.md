# CI

Self-hosted Forgejo runners on rented ephemeral VMs.

## Workflows

| Workflow          | Trigger              | Description                                                                                                                             |
| ----------------- | -------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| `build.yml`       | manual               | Builds the Android APKs, Linux AppImages and debs (x86_64, arm64) and Windows installers on several providers, verifies reproducibility |
| `check.yml`       | pull request         | Lint, format, types, unit, Rust and end-to-end tests, plus the version and backup-rules invariants                                      |
| `fdroid.yml`      | manual               | Rebuilds the per-ABI APKs the way F-Droid's buildserver does ([fdroid/](./fdroid))                                                      |
| `audit.yml`       | weekly, pull request | `cargo deny` and `bun audit`                                                                                                            |
| `credits.yml`     | pull request, push   | Regenerates the third-party credits and fails when they drift                                                                           |
| `keys.yml`        | push                 | Checks the published keys against `KEYS.md` (`verify-keys.ts`)                                                                          |
| `warm.yml`        | push                 | Keeps the check workflow caches warm                                                                                                    |
| `publish-apt.yml` | release              | Publishes the `.deb` to the Forgejo apt registry                                                                                        |
| `play.yml`        | release, manual      | Builds the Google Play app bundle on several providers, verifies reproducibility                                                        |

## Scripts

| Script                     | Used by                                                                                                                |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| `setup-build.sh`           | Build boxes, `podman` or `nix`; a job installs only what it runs                                                       |
| `check-release-version.sh` | Refuse to build a `-dev` version unless the run allows it, or a release without its `linux/NEWS.Debian` entry          |
| `linux/build.sh`           | Build, repack and name the `.deb`, then assemble the `.AppImage`, inside the Linux image                               |
| `linux/NEWS.Debian`        | Release notes the `.deb` ships for apt-listchanges, one entry per release in Debian changelog format                   |
| `windows/build.sh`         | Cross-build and name one installer, `x64` or `arm64`                                                                   |
| `android-outputs.sh`       | Name the universal and per-ABI APKs and the AAB                                                                        |
| `verify.ts`                | Every artifact, one copy per box in `BOXES`/`ARM_BOXES`; either may be empty                                           |
| `sign.ts`                  | Sign. APK: apksigner and minisign; AAB: code transparency, then jarsigner with the Play upload key; the rest: minisign |
| `play-upload.sh`           | Upload a signed AAB, its release notes and the store listing to Google Play with fastlane                              |
| `play-metadata.sh`         | Derive the Play store listing from `fastlane/metadata`: Play short description and a source code link                  |
| `cache.ts`, `rust-env.sh`  | Check runner caches                                                                                                    |
| `check-image.sh`           | The check runner image                                                                                                 |
