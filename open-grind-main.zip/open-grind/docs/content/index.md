---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

titleTemplate: ':title — free & open source Grindr client'

hero:
  name: "Open Grind"
  text: "Unofficial Grindr client"
  tagline: Free, open source client with no ads, no trackers and no paywalls, driven by the community
  actions:
    - theme: brand
      text: Download
      icon: '<span class="vp-icon i-download"></span>'
      badge: 61k
      link: /guides/download
      platforms:
        - { label: Android, icon: '<span class="vp-icon i-android"></span>' }
        - { label: Windows, icon: '<span class="vp-icon i-windows"></span>' }
        - { label: Linux, icon: '<span class="vp-icon i-linux"></span>' }
        - { label: macOS, icon: '<span class="vp-icon i-apple"></span>' }
    - theme: alt
      text: Join the Matrix chat
      icon: '<span class="vp-icon i-chat"></span>'
      link: https://matrix.to/#/#opengrind:opengrind.org
    - theme: alt
      text: Source code
      icon: '<span class="vp-icon i-forgejo"></span>'
      link: https://git.opengrind.org/open-grind/open-grind
    - theme: ghost
      text: Telegram
      icon: '<span class="vp-icon i-telegram"></span>'
      link: https://t.me/opengrind

features:
  - title: Unlocked grid
    icon: '<span class="vp-icon i-grid"></span>'
    details: Unlimited profiles for free, ads removed from grid and chats, all filters and features unlocked
    link: /guides/features/unlimited-profiles
  - title: Location spoofing
    icon: '<span class="vp-icon i-teleport"></span>'
    details: Set your location anywhere in the world for free and you'll appear in the grid there
    link: /guides/features/location-spoofing-teleport
  - title: Zero ads
    icon: '<span class="vp-icon i-no-ads"></span>'
    details: No ads, no promotions, no banners, no donation prompts, no premium features, no bloat
    link: /guides/features/no-ads
  - title: All platforms
    icon: '<span class="vp-icon i-platforms"></span>'
    details: Download for free on Android, Windows, Linux, macOS, from Google Play, apt or directly
    link: /guides/download
  - title: Privacy built-in
    icon: '<span class="vp-icon i-privacy"></span>'
    details: No analytics, no trackers, no data collected, 100% transparent logs and governance
    link: /guides/features/privacy
  - title: Security as foundation
    icon: '<span class="vp-icon i-security"></span>'
    details: Reproducible builds, human code audit, supply chain security, end-to-end testing
    link: https://git.opengrind.org/open-grind/open-grind/src/branch/main/SECURITY.md#security-policy
---

<picture class="app-screenshots">
<source media="(min-width: 1024px)" type="image/avif" srcset="/app-screenshots-1x6.avif">
<source media="(min-width: 1024px)" srcset="/app-screenshots-1x6.webp">
<source media="(min-width: 600px)" type="image/avif" srcset="/app-screenshots-3x2.avif">
<source media="(min-width: 600px)" srcset="/app-screenshots-3x2.webp">
<source type="image/avif" srcset="/app-screenshots-2x3.avif">
<img src="/app-screenshots-2x3.webp" alt="Open Grind screenshots">
</picture>
