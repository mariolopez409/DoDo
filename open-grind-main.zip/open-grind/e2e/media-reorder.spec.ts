import { expect, type Page, test } from "@playwright/test";

import {
	back,
	MEDIA_SLOT_CELL as CELL,
	openAlbum,
	openSharedAlbum,
	SHARED_ALBUM,
	TWO_ROW_ALBUM,
} from "./support/albums";
import { installTauriShim, TrustedTouch } from "./support/app";
import { CHAT_MEDIA_HOST, serveImages } from "./support/media";
import {
	cellCentersInGrid,
	expectPreviewOnDevicePixels,
	gridCorner,
	gridCornerOnceScrolled,
	heldPhotoCenter,
	type Point,
} from "./support/media-reorder";

async function revealGrid(page: Page) {
	await page
		.locator(CELL)
		.last()
		.evaluate((cell) => cell.scrollIntoView({ block: "center" }));
	await page.waitForTimeout(300);
}

async function openAlbumGrid(page: Page) {
	await openSharedAlbum(page);
	await revealGrid(page);
}

async function openTwoRowAlbumGrid(page: Page) {
	await openAlbum(page, TWO_ROW_ALBUM);
	await revealGrid(page);
}

async function holdAndDrag({
	page,
	touch,
	from,
	to,
}: {
	page: Page;
	touch: TrustedTouch;
	from: { x: number; y: number };
	to: { x: number; y: number };
}) {
	await touch.start(from.x, from.y);
	await page.waitForTimeout(500);
	for (let step = 1; step <= 12; step++) {
		await touch.move(
			from.x + ((to.x - from.x) * step) / 12,
			from.y + ((to.y - from.y) * step) / 12,
		);
		await page.waitForTimeout(20);
	}
	await touch.end();
	await page.waitForTimeout(600);
}

function mediaOrder(page: Page) {
	return page
		.locator(`${CELL} img`)
		.evaluateAll((nodes) =>
			nodes.map((node) => node.getAttribute("src") ?? ""),
		);
}

async function centerOf(page: Page, index: number) {
	const box = await page.locator(CELL).nth(index).boundingBox();
	expect(box, `cell ${index} is laid out`).not.toBeNull();
	return { x: box!.x + box!.width / 2, y: box!.y + box!.height / 2 };
}

test.describe("media reorder", () => {
	test("a touch drag needs a hold, then carries the tile along its row", async ({
		page,
	}) => {
		await openAlbumGrid(page);
		const before = await mediaOrder(page);
		expect(before.length).toBe(3);

		const first = await centerOf(page, 0);
		const third = await centerOf(page, 2);
		const touch = await TrustedTouch.attach(page);

		await touch.drag(page, first, third, { steps: 20, holdMs: 30 });
		await page.waitForTimeout(400);
		expect(
			await mediaOrder(page),
			"moving straight away is a scroll, however long it lasts",
		).toEqual(before);

		await revealGrid(page);
		const held = await centerOf(page, 0);
		const target = await centerOf(page, 1);
		await holdAndDrag({ page, touch, from: held, to: target });

		const after = await mediaOrder(page);
		expect(after, "the held tile landed one slot along").toEqual([
			before[1],
			before[0],
			before[2],
		]);
	});

	test("a held tile travels by touch into the row below", async ({
		page,
	}) => {
		await openTwoRowAlbumGrid(page);
		const before = await mediaOrder(page);
		expect(before.length).toBe(5);

		const held = await centerOf(page, 1);
		const target = await centerOf(page, 4);
		expect(target.y, "the target sits a row down").toBeGreaterThan(held.y);

		const touch = await TrustedTouch.attach(page);
		await holdAndDrag({ page, touch, from: held, to: target });

		expect(await mediaOrder(page), "the tile crossed the row").toEqual([
			before[0],
			before[2],
			before[3],
			before[4],
			before[1],
		]);
	});

	test("the new order is what the album reloads with", async ({ page }) => {
		await openAlbumGrid(page);
		const before = await mediaOrder(page);

		const third = await centerOf(page, 2);
		const first = await centerOf(page, 0);
		await page.mouse.move(third.x, third.y);
		await page.mouse.down();
		await page.mouse.move(first.x, first.y, { steps: 12 });
		await page.mouse.up();
		await page.waitForTimeout(600);

		const reordered = await mediaOrder(page);
		expect(reordered).not.toEqual(before);
		await page.getByRole("button", { name: "Save changes" }).click();
		await expect(
			page.getByRole("button", { name: "Save changes" }),
		).toBeHidden({ timeout: 30_000 });

		await back(page);
		await page.locator(SHARED_ALBUM).click();
		await page.locator(CELL).first().waitFor({ timeout: 30_000 });
		await page.waitForTimeout(500);

		expect(
			await mediaOrder(page),
			"the server kept the order we sent",
		).toEqual(reordered);
	});

	test("a drag that ends where it began changes nothing", async ({
		page,
	}) => {
		await openAlbumGrid(page);
		const before = await mediaOrder(page);

		const first = await centerOf(page, 0);
		await page.mouse.move(first.x, first.y);
		await page.mouse.down();
		await page.mouse.move(first.x + 30, first.y + 10, { steps: 8 });
		await page.mouse.move(first.x, first.y, { steps: 8 });
		await page.mouse.up();
		await page.waitForTimeout(500);

		expect(await mediaOrder(page)).toEqual(before);
		await expect(
			page.getByRole("button", { name: "Save changes" }),
			"a no-op drag leaves nothing to save",
		).toBeHidden();
	});

	test("the tile controls still work right after a drag", async ({
		page,
	}) => {
		await openAlbumGrid(page);

		const first = await centerOf(page, 0);
		const second = await centerOf(page, 1);
		await page.mouse.move(first.x, first.y);
		await page.mouse.down();
		await page.mouse.move(second.x, second.y, { steps: 12 });
		await page.mouse.up();
		await page.waitForTimeout(500);

		await page
			.getByRole("button", { name: /^Remove album photo in slot 1$/ })
			.click();
		await expect(
			page.getByRole("button", { name: /^Keep album photo in slot 1$/ }),
			"the pointer capture did not swallow the next tap",
		).toBeVisible();
	});

	test("a tile can be carried to the last slot", async ({ page }) => {
		await openAlbumGrid(page);
		const before = await mediaOrder(page);

		const first = await centerOf(page, 0);
		const last = await centerOf(page, before.length - 1);
		await page.mouse.move(first.x, first.y);
		await page.mouse.down();
		await page.mouse.move(last.x, last.y, { steps: 14 });
		await page.mouse.up();
		await page.waitForTimeout(500);

		expect(await mediaOrder(page)).toEqual([...before.slice(1), before[0]]);
	});

	test("profile photos reorder without a save round trip", async ({
		page,
	}) => {
		await installTauriShim(page);
		await serveImages(page, CHAT_MEDIA_HOST);
		await page.goto("/settings/profile");
		await page.locator(CELL).first().waitFor({ timeout: 60_000 });
		await page.waitForTimeout(600);

		const before = await mediaOrder(page);
		expect(before.length).toBeGreaterThan(1);

		const second = await centerOf(page, 1);
		const first = await centerOf(page, 0);
		await page.mouse.move(second.x, second.y);
		await page.mouse.down();
		await page.mouse.move(first.x, first.y, { steps: 12 });
		await page.mouse.up();
		await page.waitForTimeout(400);

		const after = await mediaOrder(page);
		expect(after[0], "the dragged photo leads now").toBe(before[1]);
		expect(after[1]).toBe(before[0]);
	});
});

test.describe("media reorder in a desktop window", () => {
	test.use({ viewport: { width: 800, height: 800 } });

	test("photos pushed aside by a held one sit on whole device pixels", async ({
		page,
	}) => {
		await openAlbum(page, TWO_ROW_ALBUM);
		await expectPreviewOnDevicePixels({ page, from: 0, to: 4 });
	});
});

test.describe("media reorder while the page scrolls under a held photo", () => {
	const LIFT_PX = 15;

	async function measureGrid(page: Page) {
		const centers = await cellCentersInGrid(page);
		const corner = await gridCorner(page);
		const at = ({ index, from }: { index: number; from: Point }) => ({
			x: from.x + centers[index]!.x,
			y: from.y + centers[index]!.y,
		});
		return { centers, corner, at };
	}

	async function lift({ page, at }: { page: Page; at: Point }) {
		await page.mouse.move(at.x, at.y);
		await page.mouse.down();
		await page.mouse.move(at.x + LIFT_PX, at.y, { steps: 3 });
		return { x: at.x + LIFT_PX, y: at.y };
	}

	function slotUnder({
		centers,
		corner,
		pointer,
	}: {
		centers: Point[];
		corner: Point;
		pointer: Point;
	}) {
		const distances = centers.map(({ x, y }) =>
			Math.hypot(corner.x + x - pointer.x, corner.y + y - pointer.y),
		);
		return distances.indexOf(Math.min(...distances));
	}

	test("a wheel turn drops the album photo in the slot that scrolled under the pointer", async ({
		page,
	}) => {
		await openAlbum(page, TWO_ROW_ALBUM);
		const before = await mediaOrder(page);
		const { centers, corner, at } = await measureGrid(page);

		await lift({ page, at: at({ index: 0, from: corner }) });
		const aim = at({ index: 1, from: corner });
		await page.mouse.move(aim.x, aim.y, { steps: 8 });
		await page.mouse.wheel(0, Math.round(centers[4]!.y - centers[1]!.y));
		const scrolled = await gridCornerOnceScrolled({ page, from: corner });
		expect(
			slotUnder({ centers, corner: scrolled, pointer: aim }),
			"the slot a row down scrolled under the pointer",
		).toBe(4);
		await page.mouse.up();
		await page.waitForTimeout(600);

		expect(await mediaOrder(page)).toEqual([
			before[1],
			before[2],
			before[3],
			before[4],
			before[0],
		]);
	});

	test("PageDown keeps the slot the album photo is released over", async ({
		page,
	}) => {
		await openAlbum(page, TWO_ROW_ALBUM);
		const before = await mediaOrder(page);
		const { corner, at } = await measureGrid(page);

		await lift({ page, at: at({ index: 0, from: corner }) });
		await page.keyboard.press("PageDown");
		const scrolled = await gridCornerOnceScrolled({ page, from: corner });
		const target = at({ index: 4, from: scrolled });
		await page.mouse.move(target.x, target.y, { steps: 8 });
		await page.mouse.up();
		await page.waitForTimeout(600);

		expect(await mediaOrder(page)).toEqual([
			before[1],
			before[2],
			before[3],
			before[4],
			before[0],
		]);
	});

	test("a wheel turn keeps the held profile photo under the pointer, and it lands where it is released", async ({
		page,
	}) => {
		await installTauriShim(page);
		await serveImages(page, CHAT_MEDIA_HOST);
		await page.goto("/settings/profile");
		await page.locator(CELL).first().waitFor({ timeout: 60_000 });
		await page.waitForTimeout(600);
		const before = await mediaOrder(page);
		const { corner, at } = await measureGrid(page);

		await lift({ page, at: at({ index: 1, from: corner }) });
		const held = await heldPhotoCenter(page);
		await page.mouse.wheel(0, 100);
		const scrolled = await gridCornerOnceScrolled({ page, from: corner });
		const stillHeld = await heldPhotoCenter(page);
		expect(
			Math.hypot(stillHeld.x - held.x, stillHeld.y - held.y),
			"the held photo stays under the still pointer",
		).toBeLessThan(1);

		const target = at({ index: 0, from: scrolled });
		await page.mouse.move(target.x, target.y, { steps: 8 });
		await page.mouse.up();
		await page.waitForTimeout(400);

		const after = await mediaOrder(page);
		expect(after[0], "the held photo leads now").toBe(before[1]);
		expect(after[1]).toBe(before[0]);
	});
});
